chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
	if(typeof(request["getAllValues"]) !== "undefined"){
		chrome.storage.sync.get(null, sendResponse);
		return true;
	}
	
    if(typeof(request["setValue"]) !== "undefined"){
		var data = {};
		data[request["setKey"]] = request["setValue"];
		chrome.storage.sync.set(data);
	}
  });